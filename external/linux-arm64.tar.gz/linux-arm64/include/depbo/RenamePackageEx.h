#pragma once
// part of the dll.
#include "stdtyp.h"
#include "declspecAPI.h"
#include "BisBits.h"
#ifdef _UNICODE 
#define RenamePackageEx RenamePackageW
#else
#define RenamePackageEx RenamePackageA
#endif

enum {RNP_SOURCE_FILE,RNP_OUTPUT_FILE,RNP_OLD_FILE,RNP_TEMP_FILE};
enum {RNP_PRESERVE_NONE,RNP_PRESERVE_EXT_BAK,RNP_PRESERVE_BAK_EXT,RNP_VERBOSE=BIT2};

struct _API RenamePackageEx
{
			  RenamePackageEx();
			 ~RenamePackageEx();
			 

// Creates various filenames for subsequent use.
// source_ext is appended to SourceName (if not already that ext). Built sourcename is tested for existence.
// Output is to original source, or destFileOrFolder
// Output ext is source ext, or dest_ext (if not already that ext).
// Built source and dest must, ultimately, both have extensions.
// 'how' determines whether to preserve a copy of the output (if it exists) as a 'bak'.
// two forms of bak exist, the generally used ext.bak, or bak.ext (so that the bak file can be immediately worked with in say, visitor
// An existing 'bak' is always destroyed, irrespective of how, to ensure user is aware no
// changes took place.
	//enum {RNP_PRESERVE_NONE,RNP_PRESERVE_EXT_BAK,RNP_PRESERVE_BAK_EXT};
	BOOL	 rnp_BuildOutputs(	unsigned	how,		// save copy if it exists
								UniAsc*		SourceName,	// 
								UniAsc*		source_ext=0,// added if not same
								UniAsc*		destFileOrFolder=0,
								UniAsc*		dest_ext=0);// added if not same);	

	//useful for dos progress printfs
	//enum {RNP_SOURCE_FILE,RNP_OUTPUT_FILE,RNP_OLD_FILE,RNP_TEMP_FILE};
	UniAsc*  rnp_GetFileName(unsigned what);

	// Files must be closed before calling this
	//
	// Returns sts, or over-rides a NO_ERROR sts if any internal rename failure.
	// If bad sts: no files are changed and temp is destroyed.
	// For debug mode: only a 'new' temp file is created.
	// 
	// Otherwise files are renamed appropriately dependent on sameAs source etc
	// if source is same as output, it is renamed to old (if requested). 
	// The former old is always destroyed at BuildOutputs time to ensure user is aware no fresh old is available on any error
	dos_return rnp_CloseOutputs(dos_return sts);
private:
	Void*	_rnp_void_ptr;//dont let api class anywhere near the vars
};
