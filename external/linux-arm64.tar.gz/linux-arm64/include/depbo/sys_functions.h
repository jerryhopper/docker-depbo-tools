#pragma once
//author mikero
// intended for use only by FilestringEx so that it's a one stop shop to make the conversions
// linux uses utf8. windows filenames MUST be unicode (utf16le) because any sbcs, even utf8, gets misinterpreted to cp1252
//
// clib_ means C stdlib calls versus dos system() equivalents
//

#include "cstring8u.h"

#ifdef IS_UNIX
//
// linux must downsize to utf8
// it is here where we ensure forward slash conversion
//
#include "LinuxCompat.h"

class UnixFileString:CString8
{
public:
	// pathetic that these have to be re-declared
	UnixFileString(const wchar_t *p):CString8(p){}
	UnixFileString(const char *p):CString8(p){}
	UnixFileString(const unsigned char *p):CString8((const char *)p){}

	Asciiz*	ForwardSlash()
	{
		Replace(DOS_FILE_SEPARATOR,UNIX_FILE_SEPARATOR);
		return GetString();
	}
};


#define MKDIR_FLAGS	0755	// the default for the console version is 775
//#define MKDIR_FLAGS	S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)

#define clib_fopen(fname,op) fopen(UnixFileString(fname).ForwardSlash(),op)
#define clib_stat(fname,buf)	stat(UnixFileString(fname).ForwardSlash(),buf)
#define clib_rename(from,to)	rename(UnixFileString(from).ForwardSlash(),UnixFileString(to).ForwardSlash())
#define clib_unlink(fname)	unlink(UnixFileString(fname).ForwardSlash())
#define clib_chdir(fname)	chdir(UnixFileString(fname).ForwardSlash())
#define clib_mkdir(fname)	mkdir(UnixFileString(fname).ForwardSlash(),MKDIR_FLAGS)
#define clib_getcwd			getcwd // ie not the posix _getcwd for some reason
#define clib_chdrive(x)		0
#define clib_getdrive()		0
#else //windows/dos

// windows must upsize to unicode (unix must downsize)
// windows understands forward AND backslash (unix can only use forward slash)

//returns no_error, or nonzero with errno
#define clib_chdrive(x)		_chdrive(x)
//returns nonzero with errno on error
#define clib_getdrive		_getdrive
#ifdef _UNICODE
#define clib_fopen(fname,op) _wfopen(fname,op)
#define clib_stat(fname,buf)_wstat(fname,buf)
#define clib_rename(from,to)_wrename(from,to)
#define clib_unlink(fname)	_wunlink(fname)
#define clib_chdir(fname)	_wchdir(fname)
#define clib_mkdir(fname)	_wmkdir(fname)
#define clib_getcwd			_wgetcwd

#else // utf8
//returns file pointer, or null with errno
#define clib_fopen(fname,op)	_wfopen(CStringU(fname),CStringU(op))
//returns no_error, or -1 with errno
#define clib_stat(fname,buf)	_wstat(CStringU(fname),buf)
//returns no_error, or nonzero with errno
#define clib_rename(from,to)	_wrename(CStringU(from),CStringU(to))
//returns no_error, or -1 with errno
#define clib_unlink(fname)		_wunlink(CStringU(fname))

// change drive retains a cwd for each drive
// same for cwd if a drive specified
// sys rmdir /s /q  is what is required
// linux sys rmdir -rf *but not sure it accepts all files not empty

// _chdir(setdir),_mkdir,_rmdir, _getcwd (getdir) all accept (or return) "P:\"
// _mdkir can only be one level deep
// _rmdir can only be one level deep and must be empty


//returns no_error, or -1 with errno
#define clib_chdir(fname)		_wchdir(CStringU(fname))
//returns no_error, or -1 with errno
//filestringEx ensures all parent folders happen
//mkdir accepts drive:
#define clib_mkdir(fname)		_wmkdir(CStringU(fname))
//ALWAYS returns drive:\blah or null with errno
//the buffer is released by filestringEX
#define clib_getcwd				_wgetcwd
#endif
#endif
