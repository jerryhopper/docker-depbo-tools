#pragma once

/* bisfunion is an internal debug routine not normally present in released code
** it is used to check assumption validity of floats in structures that are being analysed
*/

class BisFileIO;		

enum{FUNION_DEN=-1,FUNION_OK,FUNION_NAN,FUNION_INF};

struct _API BisFunion
{
				BisFunion(float f){Set(f);}
				BisFunion(uint32_t t){Set(t);}
				BisFunion() { FU.L = 0; }
	int32_t		Set(float f){FU.F=f;return GetInt();}
	float		Set(uint32_t t){FU.L=t;return GetFloat();}
	int32_t		GetInt(){return FU.L;}
	float		GetFloat(){return FU.F;}
	// returns 	enum{FUNION_DEN=-1,FUNION_OK,FUNION_NAN,FUNION_INF};
	int			IsFaulty();
	int			IsFaulty(float f);
	union 
	{
		float F;
		uint32_t L;
	}FU;
	uint32_t Read(BisFileIO *File);
	uint32_t Write(BisFileIO *File);
};
struct _API BisDunion
{
				BisDunion(double f){Set(f);}
				BisDunion(uint64_t t){Set(t);}
				BisDunion() { FU.L = 0; }
	int64_t		Set(double f){FU.F=f;return GetInt();}
	double		Set(uint64_t t){FU.L=t;return GetDouble();}
	int64_t		GetInt(){return FU.L;}
	double		GetDouble(){return FU.F;}
	// returns 	enum{FUNION_DEN=-1,FUNION_OK,FUNION_NAN,FUNION_INF};
	int			IsFaulty();
	int			IsFaulty(double f);
	union dunion
{
	double F;
	uint64_t L;
} FU;
	uint64_t Read(BisFileIO *File);
	uint64_t Write(BisFileIO *File);
};
