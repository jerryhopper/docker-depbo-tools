#pragma once
#include "stdtyp.h"
#include "declspecAPI.h"
/*
** generic function for dos exes to determine the nature of the source (argvariable[1])
**
**/
#ifdef _UNICODE
#define ArgSource ArgSourceW
#endif

enum {
	ARGSOURCE_UNKNOWN=-1,
	ARGSOURCE_FILE,			// source file exists
	ARGSOURCE_FOLDER,		// source folder exists
	ARGSOURCE_LIST,			// the file exists but isn't one of the extensions specified 
	ARGSOURCE_CSV			// it's a comma separated list of files, folders and possibly lists
};

class _API ArgSource
{
public:

	// returns the type of argument(s) used on a cmdline
	//
	// 'ext' accepts [.]ext1\0[.]ext2\0\0"
	//
	// returns
	// ARGSOURCE_CSV if source source contains ',,,,,'
	//  ARGSOURCE_FOLDER if source folder exists
	//  ARGSOURCE_UNKNOWN  if source\ folder specified but doesn't exist
	//  if an extension list:
	//   if `source.ext`
	//	  if csv matches source.ext
	//	   ARGSOURCE_FILE  file exists 
	//	   ARGSOURCE_UNKNOWN file doesn't
	//   else
	//    if source (no extension) matches csv
	//     ARGSOURCE_FILE
	//  else
	//     ARGSOURCE_LIST File exists
	//     ARGSOURCE_UNKNOWN file doesn't
	int  ags_type(UniAsc *source,Catenated_string *ext=0);
};

