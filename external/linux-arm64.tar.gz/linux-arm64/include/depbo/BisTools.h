#pragma once
#include "stdtyp.h"
#include "declspecAPI.h"
#include "BisBits.h"

/* author mikero
** WINDOWS ONLY. The everything is a voided for linux.
**
** this class is instanced whenever the dll is loaded. eg all exes instance the dll.
** It checks the version of the dll when it was last compiled once/day against the latest version on my website.
**
**/
class  BisTools
{
public:

						BisTools(class BisDLL *owner_unused);
						~BisTools();

		Unicode _API*	bt_get_exe_path(bitflags what);
		/*
		** First time used, it builds 3 sets of registry paths.
		**	1) arrowhead registry settings
		**	2) A3 registry settings
		**  3) Dayz registry settings.
		**
		** Mikero tools do not use this function (they could) Instead, they rely on the environ PATH setting
		**
		** Each time used it returns the path to exe if there.
		** It also checks the exe is physically where the registry says it is!
		**
		** return values are *always* "quoted\path.exe" when found and Empty when not. (no quotes)
		**
		**
		** example:
		**				FileStringEx exe=btools->bt_get_exe_path(BisTools::BT_ARMA3|BT_PAL2PACE);
		*/

#define BT_MIKERO	BIT13
#define BT_ARMA3	BIT14
#define BT_DAYZ		BIT15

enum 
{
		BT_BINARISE,			BT_SIGNFILE,	BT_PAL2PACE,	BT_CREATEKEY,BT_BIN64,	// Bis exes (BT_BIN64 is arma3 only)
		BT_RAPIFY= BT_MIKERO,	BT_MAKEPBO,		BT_DEP3D,		BT_DETEX, BT_DEWSS,		// mikero exes
};
		int		_API	bt_get_exe_version(bitflags what);
		/* current usage is for the mikero tools only, and only the above five
		** The installer for each and all exes, records the exe's version number in the registry from version.txt in the package folder
		** these registry values are retrieved any time the dll is instanced.
		** Other exes, when compiled, store the version.txt of another exe that it uses (makepbo uses rapify eg). It checks, when instanced, that dependent version is as good or better than it needs.
		** It can be better because later compiles and installs make it so. But the version it needs is always the minimum (backwards compatibility).
		**
		** the value returned is 100x the actual version number to avoid floating point innaccuraces.
		**
		** example:
		** int vers=btools->bt_get_exe_version(BisTools::BT_MAKEPBO);
		*/
private:

		Void    *void_ptr;
};
