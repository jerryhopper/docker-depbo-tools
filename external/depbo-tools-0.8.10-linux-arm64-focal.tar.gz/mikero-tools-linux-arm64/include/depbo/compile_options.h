#pragma once
// these are bug fixes which change old behaviour to something better
// they are kept here, with the older code still intact in case something goes bang in the outside world
// after a period of time with no user reports of problems with the NEW_WAY they can be deleted

//none at moment