#pragma once
/*
#include "stdtyp.h"
class DllMessages
{
public:
	DllMessages(){};//class BisDLLExt *owner){};
	~DllMessages(){};
	void ErrCallBack(Asciiz *fmt,...);
	void StdCallBack(Asciiz *fmt,...);
	void *fred;
};
*/