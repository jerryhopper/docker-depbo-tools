#pragma once
// file VersionDePbo.h
// can't be called 'version.h" because that conflicted with the 'version.h's' of all the exe's
// the nsi installer can't handle // comments on these defines
#define	DEPBO_VERSION_MAJOR	8
#define	DEPBO_VERSION_MINOR	10
// use profile.h for freebie releases. 7.97  the last freebie release

// gcc hates 08 and 09 so i simply won't use those values. better that than forgetting to define twice

#define DEPBO_VERSION (float)(DEPBO_VERSION_MAJOR+(DEPBO_VERSION_MINOR/100.0))

